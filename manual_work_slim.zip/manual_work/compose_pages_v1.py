from PIL import Image, ImageDraw, ImageFont, ImageChops
F='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
f_num=ImageFont.truetype(F,110); f_cap=ImageFont.truetype(F,34); f_q=ImageFont.truetype(F,30); f_tip=ImageFont.truetype(F,28)
BG=(248,248,248)
def crop(im):
    im=im.convert('RGB'); bg=Image.new('RGB',im.size,im.getpixel((0,0)))
    b=ImageChops.difference(im,bg).getbbox(); return im.crop(b) if b else im
def fit(im,w,h):
    im=crop(im); s=min(w/im.width,h/im.height); return im.resize((int(im.width*s),int(im.height*s)),Image.LANCZOS)
steps=[
 (1,'s1',[('bearing',2),('plate_out',1),('plate_in',1)],'베어링을 판 안쪽 가운데 구멍에 꾹 눌러 넣어요 (판 2장 모두)','튀어나온 돌기가 있는 면이 안쪽이에요'),
 (2,'s2',[('sun',1),('shaft50',1)],'짧은 쇠막대(50 mm)를 sun 구멍에 끼워요','막대 끝 = 기어 면, 딱 맞게'),
 (3,'s3',[('shaft75',1),('hub',1),('carrier',1)],'긴 쇠막대(75 mm)를 hub에 끼우고, 아래에서 hub 육각을 carrier에 꽂아요','막대 끝 = 육각 끝면, 딱 맞게'),
 (4,'s4',[('planet',3)],'planet 3개를 carrier 기둥에 끼워요','점이 있는 면을 모두 같은 쪽으로'),
 (5,'s5',[('ring',1)],'육각 구멍 판 위에 ring을 놓고, 기어 덩어리를 넣어요','판의 돌기 2개를 ring 구멍에 맞추기 · 안 들어가면 planet을 살살 돌리기'),
 (6,'s6',[('plate_in',1)],'sun을 가운데에 넣고, 둥근 구멍 판으로 덮어요','판의 작은 돌기 2개를 ring 구멍에 맞추기'),
 (7,'s7',[('bolt',4)],'모서리 4곳을 볼트·너트로 조여요','짧은 막대를 손으로 돌려 봐요: 긴 막대가 4배 느리게 돌면 성공'),
 (8,'s8',[('tray',1)],'기어 상자를 트레이에 세워요','부채꼴 창이 아래 / 긴 막대 쪽이 빈 칸 쪽'),
 (9,'s9',[('cradle',2),('screw',4),('motor',2),('coupling',2)],'받침을 날개에 나사로 고정하고, 모터를 올려 커플링으로 막대와 연결해요','모터는 케이블타이 2개로 묶기'),
 (10,'s10',[('encoder',2),('magnet',2),('bracket',2),('hall',2)],'자석 원판을 막대에 끼우고, 센서 받침을 벽 위에 세워요 (양쪽)','센서와 원판 사이 2~3 mm'),
 (11,'s11',[('tsens',1)],'온도센서를 빈 칸의 고리에 꽂아요','센서 끝이 오일에 잠기게'),
 (12,'s12',[('oil',1)],'주사기로 오일 39 mL를 빈 칸에 넣어요','안쪽 벽 가운데 긴 눈금(15 mm)까지'),
]
W,H=1400,1000
for n,img,parts,cap,tip in steps:
    P=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(P)
    # 단계 번호
    d.text((40,10),str(n),font=f_num,fill=(30,30,30))
    # 부품 상자
    bx,by=190,30; cw=170; bw=cw*len(parts)+20; bh=210
    d.rounded_rectangle([bx,by,bx+bw,by+bh],18,fill=(214,234,248),outline=(120,170,210),width=4)
    for i,(t,q) in enumerate(parts):
        th=fit(Image.open(f't_{t}.png'),140,140); x=bx+10+i*cw+(cw-th.width)//2; y=by+15+(140-th.height)//2
        P.paste(th,(x,y)); d.text((bx+10+i*cw+cw//2,by+170),f'×{q}',font=f_q,fill=(20,60,110),anchor='mm')
    # 본 그림
    m=fit(Image.open(f'{img}.png'),W-120,H-by-bh-170); P.paste(m,((W-m.width)//2,by+bh+25+(H-by-bh-170-m.height)//2))
    # 설명 + 팁
    d.text((W//2,H-105),cap,font=f_cap,fill=(20,20,20),anchor='mm')
    tw=d.textlength('!  '+tip,font=f_tip)+40
    d.rounded_rectangle([W//2-tw/2,H-70,W//2+tw/2,H-22],14,fill=(255,236,179),outline=(230,160,0),width=3)
    d.text((W//2,H-46),'!  '+tip,font=f_tip,fill=(120,70,0),anchor='mm')
    P.save(f'pages/step{n:02d}.png')
# 완성 + 부품 전체 페이지
P=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(P)
m=fit(Image.open('s13.png'),W-120,H-200); P.paste(m,((W-m.width)//2,120+(H-260-m.height)//2))
d.text((W//2,70),'완성!',font=ImageFont.truetype(F,80),fill=(30,30,30),anchor='mm')
d.text((W//2,H-60),'모터 1이 sun을 돌리면 → 반대쪽 모터 2가 4배 느리게 돌아요',font=f_cap,fill=(20,20,20),anchor='mm')
P.save('pages/step13.png')
allp=[('sun',1),('planet',3),('carrier',1),('hub',1),('ring',1),('plate_in',1),('plate_out',1),('tray',1),('cradle',2),('encoder',2),('bracket',2),
      ('bearing',2),('shaft50',1),('shaft75',1),('bolt',4),('screw',4),('motor',2),('coupling',2),('magnet',2),('hall',2),('tsens',1),('oil',1)]
names={'sun':'sun','planet':'planet','carrier':'carrier','hub':'hub','ring':'ring','plate_in':'plate_in','plate_out':'plate_out','tray':'tray','cradle':'cradle','encoder':'encoder','bracket':'bracket',
 'bearing':'베어링','shaft50':'쇠막대 50','shaft75':'쇠막대 75','bolt':'볼트+너트','screw':'나사','motor':'모터','coupling':'커플링','magnet':'자석','hall':'홀센서','tsens':'온도센서','oil':'오일 39 mL'}
P=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(P)
d.text((W//2,55),'부품을 모두 꺼내 개수를 세요',font=ImageFont.truetype(F,52),fill=(30,30,30),anchor='mm')
cols=6; cw=W//cols; ch=195
for i,(t,q) in enumerate(allp):
    r,c=divmod(i+(1 if i>=11 else 0),cols); x0=c*cw; y0=120+r*ch+(25 if i>=11 else 0)
    if t=='bearing': d.line([20,y0-12,W-20,y0-12],fill=(180,180,180),width=2)
    th=fit(Image.open(f't_{t}.png'),120,110); P.paste(th,(x0+(cw-th.width)//2,y0+(110-th.height)//2))
    d.text((x0+cw//2,y0+135),f'{names[t]}  ×{q}',font=f_tip,fill=(20,60,110) if i<11 else (60,60,60),anchor='mm')
d.text((W//2,H-30),'주황색 = 3D 프린터로 뽑은 부품 · 회색 = 산 물건',font=f_tip,fill=(90,90,90),anchor='mm')
P.save('pages/step00.png')
