use <pg.scad>
include <params.scad>
step = 8; thumb = "";
floor_t=2; wall_h=30; end_wall=6; tab_len=70; tab_t=5; wall=2.4;
z0=gap+b+boss_h+0.1;
Lx = 2*t_pl + T_ring + 0.4 + 22; tx=-t_pl-0.2;   // 트레이 안쪽 길이, 트레이 위치
zc = floor_t + H_axis;
module brg(){ difference(){ cylinder(d=10,h=3,$fn=48); translate([0,0,-1]) cylinder(d=6,h=5,$fn=32);} }
module motor(){ rotate([0,90,0]) { cylinder(d=25,h=52,$fn=48); translate([0,0,-10]) cylinder(d=4,h=10,$fn=16);} }   // 몸통 + 축(-x쪽)
module coupling(){ rotate([0,90,0]) cylinder(d=12,h=25,$fn=32); }
module bolt(){ cylinder(d=3,h=38,$fn=16); cylinder(d=5.5,h=3,$fn=24); }
module hall(){ cube([4,1.5,3]); for(i=[0:2]) translate([0.6+i*1.3,0.5,-8]) cube([0.4,0.4,8]); }
module tsens(){ cylinder(d=6,h=40,$fn=24); }
// 기어박스 완성품 (축 = x축)
module gearbox(){ translate([0,0,zc]) rotate([0,90,0]) rotate([0,0,90]) {
  translate([0,0,-t_pl]) render() plate(false); render() ring();
  translate([0,0,T_ring+t_pl]) mirror([0,0,1]) render() plate(true);
  color("SlateGray"){ translate([0,0,gap+b-50]) cylinder(d=6,h=50,$fn=32); translate([0,0,z0]) cylinder(d=6,h=75,$fn=32);} } }
module TRAY(){ translate([tx,0,0]) render() tray(); }
inX = gap+b-50; outX = z0+75;          // 입력축 끝, 출력축 끝 (x)
lc = [ -75, 0, tab_t ];  rc = [ 115, 0, tab_t ];
module CR(){ translate(lc) render() cradle(); translate(rc) render() cradle(); }
module MOT(){ color("Silver"){ translate([inX-15,0,zc]) mirror([1,0,0]) motor(); translate([outX+15,0,zc]) motor(); } }
module CPL(){ color("DimGray"){ translate([inX-15,0,zc]) coupling(); translate([outX-10,0,zc]) coupling(); } }
module ENC(){ translate([tx-end_wall-8,0,zc]) rotate([0,90,0]) render() encoder(); translate([tx+Lx+end_wall+3,0,zc]) rotate([0,90,0]) render() encoder(); }
module BRK(){ translate([tx-end_wall/2,0,floor_t+wall_h]) rotate([0,0,90]) render() bracket(); translate([tx+Lx+end_wall*1.5,0,floor_t+wall_h]) rotate([0,0,-90]) render() bracket(); }
module TS(){ color("Black") translate([tx+2*t_pl+T_ring+0.4+22-6,32,floor_t+3]) tsens(); }
module OIL(){ color("DodgerBlue",0.55) translate([tx,-(S+0.6)/2,floor_t]) cube([Lx,S+0.6,15]); }
module O(){ color("DarkOrange") children(); }
module G(){ color("Gainsboro") children(); }
if (thumb=="") {
 if(step==8){ G() TRAY(); O() translate([0,0,45]) gearbox(); }
 if(step==9){ G(){ TRAY(); gearbox(); } O(){ translate([0,0,25]) { CR(); MOT(); CPL(); } } }
 if(step==10){ G(){ TRAY(); gearbox(); CR(); } MOT(); CPL(); O() translate([0,0,25]) { ENC(); BRK(); } }
 if(step==11){ G(){ TRAY(); gearbox(); CR(); ENC(); BRK(); } MOT(); CPL(); O() translate([0,0,30]) TS(); }
 if(step==12){ G(){ TRAY(); gearbox(); CR(); ENC(); BRK(); } MOT(); CPL(); TS(); OIL(); }
 if(step==13){ color("LightGreen") TRAY(); color("SteelBlue") gearbox(); color("Tan"){ CR(); } MOT(); CPL(); color("Gold"){ ENC(); BRK(); } TS(); OIL(); }
} else {
 color("DarkOrange") {
 if(thumb=="sun") render() sun();
 if(thumb=="planet") render() planet(1);
 if(thumb=="carrier") render() carrier();
 if(thumb=="hub") render() hub();
 if(thumb=="ring") render() ring();
 if(thumb=="plate_in") render() plate(false);
 if(thumb=="plate_out") render() plate(true);
 if(thumb=="tray") render() tray();
 if(thumb=="cradle") render() cradle();
 if(thumb=="encoder") render() encoder();
 if(thumb=="bracket") render() bracket();
 }
 color("SlateGray"){
 if(thumb=="bearing") brg();
 if(thumb=="shaft50") rotate([0,90,0]) cylinder(d=6,h=50,$fn=32);
 if(thumb=="shaft75") rotate([0,90,0]) cylinder(d=6,h=75,$fn=32);
 if(thumb=="bolt") { bolt(); translate([10,0,0]) difference(){ cylinder(d=6.4,h=2.4,$fn=6); translate([0,0,-1]) cylinder(d=3,h=5,$fn=16);} }
 if(thumb=="motor") motor();
 if(thumb=="coupling") coupling();
 if(thumb=="hall") scale(3) hall();
 if(thumb=="tsens") tsens();
 if(thumb=="magnet") cylinder(d=6,h=3,$fn=32);
 if(thumb=="screw") cylinder(d=3,h=12,$fn=16);
 }
 if(thumb=="oil") color("DodgerBlue") { cylinder(d=14,h=40,$fn=32); translate([0,0,40]) cylinder(d=2,h=12,$fn=12); }
}
