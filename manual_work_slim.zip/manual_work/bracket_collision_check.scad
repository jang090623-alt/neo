use <pg.scad>
include <params.scad>
floor_t=2; wall_h=30; end_wall=6;
tx=-t_pl-0.2; Lx=2*t_pl+T_ring+0.4+22; zc=floor_t+H_axis;
module PIN_PLATE(){ translate([0,0,zc]) rotate([0,90,0]) rotate([0,0,90]) translate([0,0,-t_pl]) plate(false); }
module PLOUT(){ translate([0,0,zc]) rotate([0,90,0]) rotate([0,0,90]) translate([0,0,T_ring+t_pl]) mirror([0,0,1]) plate(true); }
// 브래킷: 끝벽 윗면 중앙(x), 긴 구멍이 벽 구멍(y=+12)에 걸리도록 c=9
module BRK_L(c){ translate([tx-end_wall/2, c, floor_t+wall_h]) bracket(); }
which = "L";
if (which=="L") intersection(){ PIN_PLATE(); BRK_L(9); }
if (which=="L2") intersection(){ PIN_PLATE(); BRK_L(-9); }
if (which=="TRAYPLATE") intersection(){ PIN_PLATE(); translate([tx,0,0]) tray(); }
