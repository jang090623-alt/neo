// ============================================================
//  윤활유 비교 실험용 유성기어 시험기 (Ultimaker 2+, PLA)
//  - 태양기어 18T / 유성기어 18T x3 / 링기어 54T, 모듈 1.5
//  - 감속비 1 + 54/18 = 4 : 1 (입력: 태양기어, 출력: 캐리어, 링기어 고정)
//  - 사용 부품: Ø6 샤프트 2개, SMF106ZZ(6x10x3, 플랜지 11.2x0.6) 2개,
//               M3 볼트 4개(35~40 mm) + 너트 4개, 커플링 2개(모터용·발전기용)
//  사용법: part 값을 바꿔 부품별로 STL을 내보낸다.
//    openscad -D 'part="sun"' -o sun.stl planetary_testrig.scad
//  모든 부품은 "출력 방향 그대로" 모델링되어 있다(서포트 불필요).
// ============================================================

part = "assembly";   // sun, planet1~3, carrier, hub, ring, plate_in, plate_out,
                     // tray, cradle, encoder, bracket, fit_test, assembly

// ---------- 기어 파라미터 ----------
m   = 1.5;           // 모듈 [mm]  (0.4 노즐로 이 두께 약 2.3 mm 확보)
zs  = 18;            // 태양기어 잇수
zp  = 18;            // 유성기어 잇수 (태양과 같게 해서 마모 비교가 쉬움)
zr  = zs + 2*zp;     // 링기어 잇수 = 54
pa  = 20;            // 압력각 [deg]
b   = 10;            // 기어 폭(치폭) [mm]
bl  = 0.10;          // 기어 1개당 이 두께 감소량(원호, mm) -> 맞물림 백래시 약 0.2 mm
tip_clear = 0.15;    // 이끝을 깎아 FDM 오차로 인한 걸림 방지 [mm]
a   = m*(zs+zp)/2;   // 중심거리 = 27 mm

// ---------- 끼움 공차 (fit_test 출력 후 수정) ----------
shaft_d    = 6.0;    // 샤프트 압입 구멍 (출력 구멍은 보통 0.1~0.2 작게 나옴)
brg_d      = 10.0;   // 베어링 외경 자리
brg_fl_d   = 11.6;   // 플랜지 자리 (11.2 + 여유)
brg_w      = 3.0;    // 베어링 폭(플랜지 포함)
brg_fl_t   = 0.6;    // 플랜지 두께
pin_d      = 5.0;    // 유성기어 핀 지름
planet_bore= 5.4;    // 유성기어 구멍 (핀과 0.4 틈 = 오일이 들어가는 미끄럼 베어링)
bolt_d     = 3.4;    // M3 관통 구멍

// ---------- 하우징 치수 ----------
S      = 96;         // 기어박스 정사각 외형 [mm]
H_axis = S/2;        // 트레이 바닥 윗면에서 축까지 높이 = 48
t_pl   = 9;          // 측판 두께
cb_d   = 18;         // 측판 안쪽 허브 공간 지름
cb_h   = 4.5;        // 허브 공간 깊이
gap    = 0.8;        // 기어와 측판 사이 축방향 틈
t_car  = 4;          // 캐리어 판 두께
boss_h = 0.5;        // 유성기어-캐리어 사이 와셔 역할 돌기
T_ring = gap + b + boss_h + 0.1 + t_car + gap;   // 링 두께 = 16.2
bolt_xy= 42;         // 볼트 위치 (±42, ±42)
hub_d  = 14;         // 태양기어 허브 지름
hub2_d = 16;         // 캐리어 출력 허브 지름
hex_af = 12;         // 캐리어-허브 결합 육각(맞변 거리)
car_r  = 33;         // 캐리어 판 반지름 (링 이끝 반지름 39.15보다 작음)

$fn = 64;

// ============================================================
//  인볼류트 치형
// ============================================================
function inv(al) = (tan(al) - al*PI/180) * 180/PI;          // [deg]
function polar(r, th) = [r*cos(th), r*sin(th)];

// 치형 1개 (x축 방향 중심). thin: 원호 두께 감소량(음수면 두꺼워짐)
module tooth(z, add, ded, thin) {
    rp = m*z/2;  rb = rp*cos(pa);  ra = rp + add;  rf = rp - ded;
    half = ((PI*m/2 - thin)/2) / rp * 180/PI;                // 피치원에서 반두께 각
    function th(r) = half + inv(pa) - inv(acos(rb/r));
    r0 = max(rb, rf);
    n  = 12;
    up = [for (i=[0:n]) let(r = r0 + (ra-r0)*i/n) polar(r, th(r))];
    lo = [for (i=[n:-1:0]) let(r = r0 + (ra-r0)*i/n) polar(r, -th(r))];
    base = [polar(rf - 0.5, -th(r0)), polar(rf - 0.5, th(r0))];
    polygon(concat([base[1]], up, lo, [base[0]]));
}

// 외접기어 2D
module gear2d(z, add=m-tip_clear, ded=1.25*m, thin=bl) {
    union() {
        circle(r = m*z/2 - ded, $fn=z*4);
        for (i=[0:z-1]) rotate(i*360/z) tooth(z, add, ded, thin);
    }
}

// 링기어의 이 홈(= 외접기어 모양 절삭 공구)
module ring_cutter2d() {
    gear2d(zr, add=1.25*m, ded=m - tip_clear, thin=-bl);
}

// 이 번호 0 표시: 삼각 홈 + ID 점(k개)
module marks(k, r_in, r_out) {
    // 0번 이 방향(+x) 반지름선 위에 표시
    translate([r_out-1.6, 0]) circle(r=0.8, $fn=3);              // 삼각형
    if (k>0) for (i=[1:k]) translate([r_out-1.6 - i*1.8, 0]) circle(r=0.6, $fn=16);
}

// ============================================================
//  부품
// ============================================================
module sun() {        // 출력 방향: 기어면 아래, 허브 위
    difference() {
        union() {
            linear_extrude(b) gear2d(zs);
            translate([0,0,b])        cylinder(d=hub_d, h=gap + cb_h - 0.4);
            translate([0,0,b+gap+cb_h-0.4]) cylinder(d=7.0, h=0.4); // 베어링 내륜에만 닿는 턱
        }
        translate([0,0,-1]) cylinder(d=shaft_d, h=40);
        translate([0,0,b-0.6]) linear_extrude(1) difference() {       // 윗면 표시(허브 바깥)
            marks(0, hub_d/2, m*zs/2 - 1.25*m);
            circle(d=hub_d+0.4);
        }
    }
}

module planet(k=1) {  // k: ID 점 개수
    difference() {
        linear_extrude(b) gear2d(zp);
        translate([0,0,-1]) cylinder(d=planet_bore, h=b+2);
        translate([0,0,b-0.6]) linear_extrude(1) marks(k, planet_bore/2, m*zp/2 - 1.25*m);
    }
}

module carrier() {    // 출력 방향: 판 아래, 핀 위
    pin_len = b + gap - 0.9;         // 핀 끝이 입력측판 안쪽면에서 0.9 떨어지도록
    difference() {
        union() {
            cylinder(r=car_r, h=t_car);
            for (i=[0:2]) rotate(i*120) translate([a,0,0]) {
                cylinder(d=8, h=t_car + boss_h);                      // 와셔 돌기(유성기어와 0.1 틈)
                cylinder(d=pin_d, h=t_car + boss_h + 0.1 + pin_len);  // 핀
            }
        }
        translate([0,0,-1]) cylinder(d=hex_af/cos(30)+0.3, h=t_car+2, $fn=6);  // 육각 소켓
        for (i=[0:2]) rotate(60+i*120) translate([19,0,-1]) cylinder(d=10, h=t_car+2); // 오일 통로
    }
}

module hub() {        // 캐리어 출력 허브: 육각부 아래, 원통 위
    difference() {
        union() {
            cylinder(d=hex_af/cos(30), h=t_car, $fn=6);
            translate([0,0,t_car]) cylinder(d=hub2_d, h=gap + cb_h - 0.4);
            translate([0,0,t_car+gap+cb_h-0.4]) cylinder(d=7.0, h=0.4);
        }
        translate([0,0,-1]) cylinder(d=shaft_d, h=30);
    }
}

module square2d() { offset(r=4) square(S-8, center=true); }

module ring() {
    difference() {
        linear_extrude(T_ring) difference() {
            square2d();
            rotate(180/zr) ring_cutter2d();   // 반 피치 회전: 유성기어 3개가 동시에 맞물리는 위상
            for (x=[-1,1], y=[-1,1]) translate([x*bolt_xy, y*bolt_xy]) circle(d=bolt_d);
            translate([-2, -S/2-1]) square([4, 7]);   // 바닥 배유 홈: 링 안쪽 오일도 트레이로 빠져 채취 가능
        }
        // 측판 위치맞춤 돌기용 구멍 (양면)
        for (zz=[-1, T_ring-2]) for (p=[[30,37],[-30,-37]]) translate([p[0],p[1],zz]) cylinder(d=4.3, h=3);
        // 이 번호 기준 눈금(윗면 바깥쪽)
        translate([0, 45.5, T_ring]) cube([1, 3, 1.2], center=true);
    }
}

// 측판: 바깥면이 바닥(z=0), 안쪽면이 위(z=t_pl)
module plate(is_out=false) {
    difference() {
        union() {
            linear_extrude(t_pl) square2d();
            for (p=[[30,37],[-30,-37]]) translate([p[0],p[1],t_pl]) cylinder(d=4, h=1.5); // 위치맞춤 돌기
        }
        // 베어링 자리: 바깥면 턱(Ø7.5) -> 베어링 -> 플랜지 -> 허브 공간
        translate([0,0,-1]) cylinder(d=7.5, h=t_pl+2);
        translate([0,0,t_pl-cb_h-brg_w]) cylinder(d=brg_d, h=brg_w+0.01);
        translate([0,0,t_pl-cb_h-brg_fl_t]) cylinder(d=brg_fl_d, h=brg_fl_t+0.01);
        translate([0,0,t_pl-cb_h]) cylinder(d=cb_d, h=cb_h+1);
        // 볼트 구멍 (+ 출력측판은 바깥면에 너트 홈)
        for (x=[-1,1], y=[-1,1]) translate([x*bolt_xy, y*bolt_xy, 0]) {
            translate([0,0,-1]) cylinder(d=bolt_d, h=t_pl+2);
            if (is_out) translate([0,0,-1]) cylinder(d=6.4, h=3.4, $fn=6);
        }
        // 오일 창: 축 아래쪽 부채꼴 2개 (트레이의 오일이 기어 안으로 들어옴)
        for (ang=[[205,255],[285,335]]) translate([0,0,-1]) linear_extrude(t_pl+2)
            polygon(concat([for (t=[ang[0]:5:ang[1]]) polar(40, t)],
                           [for (t=[ang[1]:-5:ang[0]]) polar(12, t)]));
    }
}

// ---------- 오일 트레이 + 모터 받침 레일 ----------
tray_in_x = 2*t_pl + T_ring + 0.4;   // 기어박스가 들어가는 길이
well_x    = 22;                      // 주사기 채취·온도센서 공간
tray_in_y = S + 0.6;
wall      = 2.4;  end_wall = 6;  floor_t = 2;  wall_h = 30;
tab_len   = 70;  tab_w = 40;  tab_t = 5;

module tray() {
    Lx = tray_in_x + well_x;
    difference() {
        union() {
            // 바닥 + 벽
            translate([-end_wall, -tray_in_y/2-wall, 0]) cube([Lx+2*end_wall, tray_in_y+2*wall, floor_t+wall_h]);
            // 모터 받침 레일 (양쪽)
            translate([-end_wall-tab_len, -tab_w/2, 0]) cube([tab_len, tab_w, tab_t]);
            translate([Lx+end_wall, -tab_w/2, 0]) cube([tab_len, tab_w, tab_t]);
        }
        translate([0, -tray_in_y/2, floor_t]) cube([Lx, tray_in_y, wall_h+1]);
        // 레일 나사 구멍(Ø2.5, 5 mm 간격) : M3 셀프태핑으로 받침 고정
        for (s=[0,1]) for (i=[0:12])
            translate([s==0 ? -end_wall-tab_len+5+i*5 : Lx+end_wall+5+i*5, 0, -1]) cylinder(d=2.5, h=tab_t+2);
        // 브래킷 고정 구멍 (양 끝벽 윗면)
        for (x=[-end_wall/2, Lx+end_wall/2], y=[-12, 12]) translate([x, y, floor_t+wall_h-10]) cylinder(d=2.5, h=11);
        // 수위 눈금 (채취 공간 안쪽 벽, 바닥에서 10/15/20 mm)
        for (h=[10,15,20]) translate([Lx-0.5, 20, floor_t+h-0.3]) cube([1, h==15?16:8, 0.6]);
    }
    // 기어박스 밀림 방지 턱
    translate([tray_in_x, -tray_in_y/2, floor_t]) cube([1.5, tray_in_y, 2]);
    // 온도센서(DS18B20 Ø6) 고정 링 : 채취 공간 벽에 붙임
    translate([tray_in_x + well_x - 6, 32, floor_t+14]) difference() {
        cylinder(d=10, h=16);
        translate([0,0,-1]) cylinder(d=6.5, h=18);
    }
}

// 모터 받침: 원통형 모터 지름 motor_d 에 맞춰 케이블타이로 고정
motor_d = 25;    // 사용할 모터 몸통 지름으로 수정
module cradle() {
    ax = floor_t + H_axis - tab_t;   // 레일 윗면에서 축 높이 = 45
    difference() {
        translate([-15, -20, 0]) cube([30, 40, ax]);
        translate([-20, 0, ax]) rotate([0,90,0]) cylinder(d=motor_d+0.6, h=40);
        for (x=[-8, 8]) translate([x-2, -25, ax-motor_d/2-4]) cube([4, 50, 2.2]);  // 케이블타이 통로
        hull() for (x=[-5,5]) translate([x,0,-1]) cylinder(d=3.4, h=ax);         // 레일 고정 긴 구멍
        hull() for (x=[-5,5]) translate([x,0,6]) cylinder(d=6.5, h=ax);          // 나사머리 공간
    }
}

// 회전수 측정용 자석 원판 (홀센서 3144)
mag_d = 6.3;  mag_h = 3.2;   // 자석 크기(지름 6 x 3 mm 기준)에 맞춰 수정
module encoder() {
    difference() {
        cylinder(d=26, h=5);
        translate([0,0,-1]) cylinder(d=shaft_d, h=7);
        translate([9,0,5-mag_h]) cylinder(d=mag_d, h=mag_h+1);
    }
}

// 홀센서 브래킷: 끝벽 윗면에 M3로 고정, 세로 긴 구멍으로 높이 조절
module bracket() {
    difference() {
        union() {
            translate([-7, -15, 0]) cube([14, 30, 4]);
            translate([-7, 11, 0]) cube([14, 4, 30]);
        }
        hull() for (y=[-10, 2]) translate([0,y,-1]) cylinder(d=3.4, h=6);
        hull() for (z=[8, 26]) translate([0,10,z]) rotate([-90,0,0]) cylinder(d=3.4, h=6);
    }
}

// 공차 시험편: 구멍 지름을 바꿔 가며 샤프트·베어링·핀 끼움 확인
module fit_test() {
    difference() {
        translate([-2,-2,0]) cube([74, 36, 5]);
        for (i=[0:4]) translate([6+i*14, 8, -1])  cylinder(d=9.8+i*0.1, h=7);   // 베어링 9.8~10.2
        for (i=[0:4]) translate([6+i*14, 24, -1]) cylinder(d=5.8+i*0.1, h=7);   // 샤프트 5.8~6.2
    }
    for (i=[0:2]) translate([80, 4+i*12, 0]) difference() {                     // 유성 구멍 5.3~5.5
        cylinder(d=10, h=5); translate([0,0,-1]) cylinder(d=5.3+i*0.1, h=7);
    }
    translate([96, 16, 0]) cylinder(d=pin_d, h=12);                                 // 핀 시험
}

// ============================================================
//  조립 확인용 (축 = x축, 입력측판 안쪽면이 x=0)
// ============================================================
sel = "all";   // 조립 확인에서 한 부품만 보고 싶을 때
module assembly() {
    // 축 = x축, 입력측판 안쪽면이 x=0, 오일 창(부품 좌표 -y)이 아래를 향하도록 회전
    zc = floor_t + H_axis;
    translate([0,0,zc]) rotate([0,90,0]) rotate([0,0,90]) {
        if (sel=="all"||sel=="plate_in")  translate([0,0,-t_pl]) plate(false);
        if (sel=="all"||sel=="ring")      ring();
        if (sel=="all"||sel=="plate_out") translate([0,0,T_ring+t_pl]) mirror([0,0,1]) plate(true);
        if (sel=="all"||sel=="sun")       translate([0,0,gap+b]) mirror([0,0,1]) sun();
        for (i=[0:2]) if (sel=="all"||sel==str("planet",i+1))
            rotate(i*120) translate([a,0,gap]) rotate(180/zp) planet(i+1);
        if (sel=="all"||sel=="carrier")   translate([0,0,gap+b+boss_h+0.1+t_car]) mirror([0,0,1]) carrier();
        if (sel=="all"||sel=="hub")       translate([0,0,gap+b+boss_h+0.1]) hub();
    }
    if (sel=="all"||sel=="tray") translate([-t_pl-0.2, 0, 0]) tray();
}

if (part=="sun") sun();
else if (part=="planet1") planet(1);
else if (part=="planet2") planet(2);
else if (part=="planet3") planet(3);
else if (part=="carrier") carrier();
else if (part=="hub") hub();
else if (part=="ring") ring();
else if (part=="plate_in") plate(false);
else if (part=="plate_out") plate(true);
else if (part=="tray") tray();
else if (part=="cradle") cradle();
else if (part=="encoder") encoder();
else if (part=="bracket") bracket();
else if (part=="fit_test") fit_test();
else if (part=="gear2d_sun") gear2d(zs);
else if (part=="ring2d") difference() { square2d(); rotate(180/zr) ring_cutter2d(); }
else assembly();
